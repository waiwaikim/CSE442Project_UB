<?php

    function sqlConnect() {
    // make a connection to SQL DB

        $servername = "tethys.cse.buffalo.edu";
        $username = 'waiwaiki';
        $password = '50180101';
        $database = 'cse442_542_2019_summer_teamd_db';

        $conn = new mysqli($servername, $username, $password, $database) or die ("Connection failed: " . mysqli_connect_error());

        if (mysqli_connect_error()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }
        else {
            return $conn; 
        }
    }


    function checkValidStudent($conn, $email){
    // read function
    // check if an email belongs to an active student 
        
        $stmt = $conn->prepare("SELECT ubit FROM roster_csvInput WHERE ubit = ?");
        $stmt->bind_param("s", substr($email,0, strpos($email,'@')));
        $stmt->execute();
        $stmt->bind_result($ubit);
        $stmt->fetch();
    
        if($ubit == "") {

            $valid = false; 
        }
        else {
            $valid = true;
        }
        
       
        return $valid; 
    }

    function checkEmail($conn, $email){
        $stmt = $conn->prepare("SELECT code FROM loginInfo WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($code);
        $stmt->fetch();
        
        return $code;
    }

    function insertEmail($conn, $email, $code) {
    // write function to a SQL DB
    // insert a new Email address 
        
        //$conn2 = sqlConnect();
        
        //$codeFound= checkEmail($conn2, $email);
        //echo " found code is " . $codeFound;
        $codeFound = "dfnjdnflad3124";
  
      //  if ($codeFound == "") {
        // when a new email is entered
            
//            $stmt2 = $conn->prepare("INSERT INTO loginInfo (email, ubit, code) VALUES (?, ?,  ?)");
//            $stmt2->bind_param("sss", $email,substr($email,0, strrpos($email,'@')), $code );
//            $stmt2->execute();
//            $stmt->close();
//            $conn->close();
           

   //     else {
        //when an existing email is entered
 //           echo "I'm in here ";
//            $stmt2 = $conn->prepare("UPDATE loginInfo SET code = ? WHERE email = ? ");
//            $stmt2->bind_param("ss",  $code, $email  );
//            $stmt2->execute();
//            $stmt->close();
//            $conn->close();
            
        }     
       

    }

    function getConfirmCode($conn, $email) {
    // read function
    // return a confirmation code for a given email 

        $stmt = $conn->prepare("SELECT code FROM loginInfo WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($code);
        $stmt->fetch();
        
     
        if ($code == "") {
            echo 'Failed to login: your confirmation code is incorrect' . mysql_error();
            exit;
        }

        //echo "<br>" . $row['code'];
        return $code;
        
    }
?>